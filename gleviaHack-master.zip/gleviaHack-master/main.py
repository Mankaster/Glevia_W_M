import pyautogui
import time
from ahk import AHK


def wyjeb_ze_spawna():
    print("LOKALIZUJE NIEBIESKIE GÓWNO")
    ahk.key_down('t')
    time.sleep(3)
    ahk.key_up('t')
    ahk.key_down('f')
    time.sleep(2)
    ahk.key_up('f')
    niebieskiegowno = pyautogui.locateCenterOnScreen("niebieskiegowno.png", confidence=0.6)
    while not niebieskiegowno:
        ahk.key_press('e')
        niebieskiegowno = pyautogui.locateCenterOnScreen("niebieskiegowno.png", confidence=0.6)
    print("NIEBIESKIE GÓWNO ZNALEZIONE")
    pyautogui.moveTo(niebieskiegowno)
    pyautogui.click(button="left")
    print("WYJEBA ZE SPAWNA")
    ahk.key_down('w')
    time.sleep(4)
    ahk.key_up('w')


def znajdz_i_zbij_metina():
    print("ZNAJDUJE I ZBIJAM METINA")
    metin = pyautogui.locateCenterOnScreen("metin.png", confidence=0.75)
    while not metin:
        ahk.key_press('e')
        metin = pyautogui.locateCenterOnScreen("metin.png", confidence=0.75)
    print(metin)
    pyautogui.moveTo(metin)
    pozycja_nazwy_metina = pyautogui.position()
    pozycja_metina = pozycja_nazwy_metina[1] + 90
    pyautogui.moveTo(pozycja_nazwy_metina[0], pozycja_metina)
    pyautogui.click(button='left')
    metin_opis = pyautogui.locateCenterOnScreen("metin3.png", confidence=0.6)
    while not metin_opis:
        metin_opis = pyautogui.locateCenterOnScreen("metin3.png", confidence=0.6)
    time.sleep(8)

def zbij_fale_przeciwnikow():
    print("ZBIJAM FALE PRZECIWNIKÓW")
    metin = pyautogui.locateCenterOnScreen("metin.png", confidence=0.65)
    while not metin:
        ahk.key_down('e')
        ahk.key_down('space')
        time.sleep(5)
        ahk.key_up('e')
        ahk.key_down('d')
        time.sleep(6)
        ahk.key_press('2')
        ahk.key_up('d')
        metin = pyautogui.locateCenterOnScreen("metin.png", confidence=0.55)

    ahk.key_up('e')
    ahk.key_up('space')
    print(metin)


def zbij_bossy(nazwa_bossa):
    print(f"ZBIJAM {nazwa_bossa.upper()}")
    boss = pyautogui.locateCenterOnScreen(f"{nazwa_bossa}.png", confidence=0.65)
    ahk.key_down('space')
    while not boss:
        time.sleep(5)
        ahk.key_press('2')
        boss = pyautogui.locateCenterOnScreen(f"{nazwa_bossa}.png", confidence=0.65)
    while boss:
        ahk.key_press('a')
        ahk.key_down('space')
        ahk.key_press('d')
        boss = pyautogui.locateCenterOnScreen(f"{nazwa_bossa}.png", confidence=0.65)
    ahk.key_up('space')


def ponow_wyprawe():
    print('PONAWIAM WYPRAWĘ')
    przycisk = pyautogui.locateCenterOnScreen(f"ponow_wyprawe.png", confidence=0.75)
    pyautogui.moveTo(przycisk)


ahk = AHK()
pyautogui.getWindowsWithTitle("Glevia2")[0].activate()
time.sleep(1)

# brak_kluczy = pyautogui.locateCenterOnScreen("f3.png", confidence=0.65)

wyjeb_ze_spawna()
znajdz_i_zbij_metina()
zbij_fale_przeciwnikow()
znajdz_i_zbij_metina()
zbij_bossy('komendanci')
zbij_bossy('komendanci')
ahk.key_press('a')
ahk.key_down('space')
time.sleep(3)
ahk.key_up('space')
ahk.key_down('t')
time.sleep(2)
ahk.key_up('t')
znajdz_i_zbij_metina()
zbij_fale_przeciwnikow()
znajdz_i_zbij_metina()
zbij_bossy('dowodca')
znajdz_i_zbij_metina()
zbij_bossy('smok')
print("DUNG ZROBIONY")
ponow_wyprawe()
